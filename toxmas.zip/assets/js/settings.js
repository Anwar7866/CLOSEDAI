tailwind.config = {
    darkMode: 'dark',
}